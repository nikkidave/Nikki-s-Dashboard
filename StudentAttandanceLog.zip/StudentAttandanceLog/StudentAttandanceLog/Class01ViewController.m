//
//  ViewController.m
//  gesture recognizers 01
//
//  Created by Dave,Nakshatra on 3/31/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

#import "Class01ViewController.h"
#import "StudentView.h"
#import "Student.h"
#import "Attendance.h"
#import "AbsentLogViewController.h"
#import "XYZAppDelegate.h"


@interface Class01ViewController ()
@property CGPoint dragOrigin;

@property NSMutableArray * students;
@property StudentView * currStudent;
@property StudentView * stuImage;

@property XYZAppDelegate * delegate;
@property NSManagedObjectContext * managedObjectContext;
@property NSNumber *location;
@property bool checkClick;


@end

@implementation Class01ViewController

@synthesize checkClick;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.delegate= [UIApplication sharedApplication].delegate;                  
    self.managedObjectContext= self.delegate.managedObjectContext;
    
    self.checkClick= NO;
    self.studentViewPlaceHolder.center= CGPointMake(650,800);
    //   UIBarButtonItem * populateRosterBTN = [[UIBarButtonItem alloc]initWithTitle:@"Populate Roster" style:UIBarButtonItemStylePlain target:self action:@selector(readStudentRoster:)];
    //   self.navigationItem.rightBarButtonItem = populateRosterBTN;
    
    self.students = [NSMutableArray array];
    [self loadData:self.classID];
    
    UIRotationGestureRecognizer * handleRotate = [[UIRotationGestureRecognizer alloc]initWithTarget:self action:@selector(handleRotate:)];
    [self.teacherImage addGestureRecognizer:handleRotate];
    
    //UIPanGestureRecognizer *dragTeacher= [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(dragTeacher:)];
    //[self.teacherImage addGestureRecognizer:dragTeacher];

}

-(void)loadData:(NSString *) classID
{
    
    NSFetchRequest * fetchRequest = [[NSFetchRequest alloc]init];
    fetchRequest.entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:self.managedObjectContext];
    fetchRequest.predicate = [NSPredicate predicateWithFormat:@"classID == %@",classID];
    NSError * error;
    NSArray * students = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
    
    
    int numStudents = students.count;
    NSLog(@"%lu students ",(unsigned long)students.count);
    
    
    for(int i = 0; i < numStudents; i++)
    {
        UIPanGestureRecognizer * dragStudent = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handleDrag:)];
        UITapGestureRecognizer * clickedViewID=[[[UITapGestureRecognizer alloc]init]initWithTarget:self action:@selector(clickLabel:)];
        [clickedViewID setNumberOfTapsRequired:2];
        
        UITapGestureRecognizer * clicktoRemove=[[[UITapGestureRecognizer alloc]init]initWithTarget:self action:@selector(clickToRemove:)];
        clicktoRemove.numberOfTapsRequired = 2;
        clicktoRemove.numberOfTouchesRequired = 2;
        
        UILongPressGestureRecognizer * getStudentImage= [[[UILongPressGestureRecognizer alloc]init] initWithTarget:self action:@selector(getStudentImage:)];
        
        
        StudentView *studentView = [[StudentView alloc] initWithFrame:CGRectMake(self.studentViewPlaceHolder.frame.origin.x, self.studentViewPlaceHolder.frame.origin.y, self.studentViewPlaceHolder.frame.size.width,self.studentViewPlaceHolder.frame.size.height) studentName: ((Student *)[students objectAtIndex:i]).name studentImage:((Student *)[students objectAtIndex:i]).studentImage];
        
        
        studentView.name = [NSString stringWithFormat:@"%d", i];
        studentView.center=CGPointFromString(((Student*)students[i]).location);
        
        studentView.student = students[i];
        
        
        [self.view addSubview:studentView];
        [self.students addObject:studentView];
        [studentView addGestureRecognizer:clickedViewID];
        [studentView addGestureRecognizer:clicktoRemove];
        [studentView addGestureRecognizer:getStudentImage];
        
        [studentView addGestureRecognizer:dragStudent];
    }

    
}


-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

-(void)getStudentImage:(UILongPressGestureRecognizer *) longPress
{
    self.currStudent = nil;
    
    NSLog(@"Long press handler has been called");
    
    self.currStudent= (StudentView *)longPress.view;
    
    self.imagepicker=[[UIImagePickerController alloc]init];
    self.imagepicker.delegate=self;
    [self.imagepicker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    [self presentViewController:self.imagepicker animated:YES completion:nil];
    
    
}
- (void)handleRotate:(UIRotationGestureRecognizer *)recognizer {
    
    // current value is past rotations + current rotation
    
    
    
    
    float rotation = angle + -recognizer.rotation;
    
    self.teacherImage.transform = CGAffineTransformMakeRotation(-rotation);
    
    
    // once the user has finsihed the rotate, save the new angle
    
    if (recognizer.state == UIGestureRecognizerStateEnded) {
        
        angle = rotation;
        
    }
    
}



-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    self.image=[info objectForKey:UIImagePickerControllerOriginalImage];
   
    [self dismissViewControllerAnimated:YES completion:nil];
    
    NSFetchRequest * fetchRequest = [[NSFetchRequest alloc]init];
    fetchRequest.entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:self.managedObjectContext];
    fetchRequest.predicate = [NSPredicate predicateWithFormat:@"name == %@",self.currStudent.studentNameTF.text];
    
    
    
    
    
    NSArray * students = [self.managedObjectContext executeFetchRequest:fetchRequest error:nil];
    Student * student = students[0];
    NSData * imageData=UIImageJPEGRepresentation(self.image, 1.0);
    student.studentImage=imageData;
    NSError * error;
    [self.managedObjectContext save:&error];
    [self.currStudent redrawThyself];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    NSLog(@"I am class %@",self.classID);
    

    
    
    
}

-(void)clickToRemove:(UITapGestureRecognizer *)click
{
    StudentView * currStudent = nil;
    currStudent= (StudentView *)click.view;
    
    NSFetchRequest * fetchRequest = [[NSFetchRequest alloc]init];

   fetchRequest = [[NSFetchRequest alloc]init];
    
    for (Attendance * att in currStudent.student.absenceLog) {
         [self.managedObjectContext deleteObject:att];
    }
    
    [self.managedObjectContext deleteObject:currStudent.student];
    
    [currStudent removeFromSuperview];
    
    [self.managedObjectContext save:nil];
}

-(IBAction)DeleteAllStudents:(id)sender
{
    
    NSFetchRequest * fetchRequest = [[NSFetchRequest alloc]init];
    fetchRequest.entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:self.managedObjectContext];
    NSError * error;
    NSArray * fetchedStudents = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
    
    int numStudents = fetchedStudents.count;

    for (int i=0 ; i<numStudents; i++) {
        fetchRequest = [[NSFetchRequest alloc]init];
        fetchRequest.entity = [NSEntityDescription entityForName:@"AbsentLog" inManagedObjectContext:self.managedObjectContext];
         fetchRequest.predicate = [NSPredicate predicateWithFormat:@"student == %@",fetchedStudents[i]];
        NSError * errorLog;
        NSArray * fetchedLogs = [self.managedObjectContext executeFetchRequest:fetchRequest error:&errorLog];
        for(Attendance * att in fetchedLogs)
        {
             [self.managedObjectContext deleteObject:att];
        }
        [self.managedObjectContext deleteObject:fetchedStudents[i]];
        
     
    }
    [self.managedObjectContext save:&error];
    
    
    for(UIView * view in self.view.subviews)
    {
        if([view class] == [StudentView class])
        {
            if(view.tag != 1)
                [view removeFromSuperview];
        }
    }
    
}


-(void)clickLabel : (UITapGestureRecognizer *) click
{
    StudentView * currStudent = nil;
    
    
    currStudent= (StudentView *)click.view;
    
    
    
    NSFetchRequest * fetchRequest = [[NSFetchRequest alloc]init];
    fetchRequest.entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:self.managedObjectContext];
    fetchRequest.predicate = [NSPredicate predicateWithFormat:@"name == %@",currStudent.studentNameTF.text];
    
    NSArray * students = [self.managedObjectContext executeFetchRequest:fetchRequest error:nil];
    Student * student = students[0];
    
    
    fetchRequest = [[NSFetchRequest alloc]init];
    fetchRequest.entity = [NSEntityDescription entityForName:@"AbsentLog" inManagedObjectContext:self.managedObjectContext];
    //fetchRequest.predicate = [NSPredicate predicateWithFormat:@"name == %@",currStudent.studentNameTF.text];
    NSArray * absentLogs = [self.managedObjectContext executeFetchRequest:fetchRequest error:nil];
    
    BOOL prevMarkedAbsent = false;
    
    Attendance * prevAbsLog = nil;
    
    for(Attendance * absentLog in absentLogs)
    {
        Student * student = absentLog.student;
        if([student.name isEqualToString:currStudent.studentNameTF.text])
        {
            prevMarkedAbsent = YES;
            prevAbsLog = absentLog;
        }
        if(prevMarkedAbsent)
            break;
    }
    NSDateFormatter * dateFormmater = [[NSDateFormatter alloc]init];
    [dateFormmater setDateFormat:@"MM-dd-YYYY"];

    if(!prevMarkedAbsent)
    {
        Attendance * absentLog= [NSEntityDescription insertNewObjectForEntityForName:@"AbsentLog" inManagedObjectContext:self.managedObjectContext];
        
        absentLog.date=[NSDate date];
        absentLog.classID= self.classID;
        absentLog.student = student;
        
        
        absentLog.absents = [NSString stringWithFormat:@"%@",[dateFormmater stringFromDate:absentLog.date]];
        
        [self.managedObjectContext save:nil];
        
        NSLog(@"Added a log entry");
    }
    else
    {
        NSLog(@"Already marked absent");
        NSDate * today = [NSDate date];
        NSString * todaysDate = [dateFormmater stringFromDate:today ];
        prevAbsLog.absents = [NSString stringWithFormat:@"%@, %@",prevAbsLog.absents,todaysDate];
        [self.managedObjectContext save:nil];
    }
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle: @"Absent"
                                                   message: [NSString stringWithFormat:@"%@ marked absent!",student.name]
                                                  delegate: self
                                         cancelButtonTitle:@"OK"
                                         otherButtonTitles:nil,nil];
    
    
    [alert show];
}




-(IBAction)handleDrag:(UIPanGestureRecognizer *)panner{
    StudentView * currentStudent = (StudentView *)panner.view;
    
    if([panner.view isKindOfClass:[StudentView class]])
    {
        currentStudent = (StudentView *)panner.view;
    }
    
    if(panner.state    == UIGestureRecognizerStateBegan)self.dragOrigin= currentStudent.center;
    // translationInView is cumulative until the user stops dragging
    CGPoint delta = [panner translationInView :currentStudent.superview ];
    currentStudent.center = CGPointMake(self.dragOrigin.x+delta.x,self.dragOrigin.y+delta.y); //new positions to save
    if (panner.state  == UIGestureRecognizerStateEnded )
    {
        CGPoint loc=[panner locationInView:self.view];
        if(currentStudent!=nil)
        {
            currentStudent.student.location= NSStringFromCGPoint(loc);
            
            
            NSFetchRequest * fetchRequest = [[NSFetchRequest alloc]init];
            fetchRequest.entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:self.managedObjectContext];
            fetchRequest.predicate = [NSPredicate predicateWithFormat:@"name == %@",currentStudent.studentNameTF.text];
            
            NSError * error;
            NSArray * students = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
            
            
            
            if(students.count!=0)
            {
                Student * studentLocationUpdate=students[0];
                NSLog(@"location %@",studentLocationUpdate.location);
                studentLocationUpdate.location=NSStringFromCGPoint(loc);
                [self.managedObjectContext save:&error];
                NSLog(@"location change %@",studentLocationUpdate.location);
            }
            else
            {
                NSLog(@"No student found!");
            }
            
        }
        
        
    }
    //[self.managedObjectContext save:nil];
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)populateClass01:(id)sender {
    [self.delegate insertDataForClass:self.classID withURL:@"https://dl.dropboxusercontent.com/u/19400137/TheMultiverse/44-543-iOS-s14/Class01Roster.txt"];
    [self loadData:self.classID];
}

- (IBAction)populateClass03:(id)sender {
    NSLog(@"class 3");
    [self.delegate insertDataForClass:self.classID withURL:@"https://dl.dropboxusercontent.com/u/19400137/TheMultiverse/44-543-iOS-s14/Class03Roster.txt"];
    [self loadData:self.classID];
}

- (IBAction)populateClass02:(id)sender {
    
    [self.delegate insertDataForClass:self.classID withURL:@"https://dl.dropboxusercontent.com/u/19400137/TheMultiverse/44-543-iOS-s14/Class02Roster.txt"];
    [self loadData:self.classID];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    AbsentLogViewController * absentLog = [segue destinationViewController];
    absentLog.managedObjectContext = self.managedObjectContext;
    absentLog.classID=self.classID;
}
@end
