//
//  AbsentLogViewController.m
//  StudentAttandanceLog
//
//  Created by Dave,Nakshatra on 4/17/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

#import "AbsentLogViewController.h"
#import "Attendance.h"
#import "Student.h"

@interface AbsentLogViewController ()
@property NSArray * absentLog;

@end

@implementation AbsentLogViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSError * error;
    
    
    NSFetchRequest * fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"AbsentLog"];
    fetchRequest.predicate = [NSPredicate predicateWithFormat:@"classID == %@",self.classID];
    self.absentLog = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
    
      NSLog(@"%@",self.absentLog);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return  1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.absentLog count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    Attendance * att = self.absentLog[indexPath.row];
    NSArray * numberOfTimesStudentAbsent = [att.absents componentsSeparatedByString:@","];
    cell.textLabel.text = [NSString stringWithFormat:@"%@ %d",att.student.name,[numberOfTimesStudentAbsent count]];
    cell.textLabel.textColor = [numberOfTimesStudentAbsent count] > 2 ? [UIColor orangeColor] : [UIColor blackColor];
    cell.detailTextLabel.text = att.absents;  //[[att.date description] substringToIndex:10];
    
    return cell;
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

/*
 #pragma mark - Navigation
 
 // In a story board-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
 {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 
 */

@end
