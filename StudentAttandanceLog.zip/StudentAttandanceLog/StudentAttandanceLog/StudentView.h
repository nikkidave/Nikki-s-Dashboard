//
//  StudentView.h
//  gesture recognizers 01
//
//  Created by Dave,Nakshatra on 4/3/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Student.h"
#import "XYZAppDelegate.h"
@interface StudentView : UIView
@property Student * student;

@property CGPoint location;
@property NSString * name;
@property int rollNum;
@property UIImageView * studentIV;
@property UITextField * studentNameTF;
@property XYZAppDelegate * appDelegate;
@property NSManagedObjectContext * managedObjectContext;

- (id)initWithFrame:(CGRect)frame studentName: (NSString *)name studentImage:(NSData *)studentImage;

-(void)redrawThyself;
@end
