//
//  ViewController.h
//  gesture recognizers 01
//
//  Created by Dave,Nakshatra on 3/31/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Class01ViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    float angle;
    
    
}
@property NSString * classID;
@property UIImagePickerController * imagepicker;
@property UIImage * image;
- (IBAction)DeleteAllStudents:(id)sender;


@property (weak, nonatomic) IBOutlet UIImageView *teacherImage;
- (IBAction)populateClass01:(id)sender;
- (IBAction)populateClass03:(id)sender;

- (IBAction)populateClass02:(id)sender;

@property (weak, nonatomic) IBOutlet UIView *studentViewPlaceHolder;
@end
