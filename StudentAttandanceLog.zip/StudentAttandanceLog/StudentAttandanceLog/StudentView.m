//
//  StudentView.m
//  gesture recognizers 01
//
//  Created by Dave,Nakshatra on 4/3/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

#import "StudentView.h"
#import "XYZAppDelegate.h"
@interface StudentView()

@end
@implementation StudentView
@synthesize location,rollNum;

- (id)initWithFrame:(CGRect)frame studentName: (NSString *)name studentImage:( NSData *)studentImage
{
    self = [super initWithFrame:frame];
    self.backgroundColor = [UIColor whiteColor];
    if (self) {
       
        
        self.studentIV = [[UIImageView alloc]initWithFrame:CGRectMake(20,5,50,50)];
        if(studentImage == nil){
        self.studentIV.image = [UIImage imageNamed:@"earth0.jpeg"];
        
        }
        else{
            
            //self.studentIV.image= [UIImage imageWithData:studentImage scale:1.0];
            
            [self.studentIV setImage:[UIImage imageWithData:studentImage]];
        }
        self.studentNameTF = [[UITextField alloc]initWithFrame:CGRectMake(10,70,100,20)];
        
        self.studentNameTF.text = name;
        self.studentNameTF.font = [UIFont fontWithName:@"Helvetica" size:16.0];
        [self addSubview:self.studentIV];
        [self addSubview:self.studentNameTF];
    }
    return self;
}


-(void)redrawThyself{
    [self.studentIV setImage:[UIImage imageWithData:self.student.studentImage]];
}

@end
