//
//  AbsentLogViewController.h
//  StudentAttandanceLog
//
//  Created by Dave,Nakshatra on 4/17/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AbsentLogViewController : UITableViewController
@property NSManagedObjectContext * managedObjectContext;
@property NSString * classID;
@end
