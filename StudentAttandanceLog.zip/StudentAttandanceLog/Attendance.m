//
//  Attendance.m
//  StudentAttandanceLog
//
//  Created by Dave,Nakshatra on 4/24/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

#import "Attendance.h"
#import "Student.h"


@implementation Attendance

@dynamic absents;
@dynamic classID;
@dynamic date;
@dynamic student;

@end
