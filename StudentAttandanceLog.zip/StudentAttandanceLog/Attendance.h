//
//  Attendance.h
//  StudentAttandanceLog
//
//  Created by Dave,Nakshatra on 4/24/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Student;

@interface Attendance : NSManagedObject

@property (nonatomic, retain) NSString * absents;
@property (nonatomic, retain) NSString * classID;
@property (nonatomic, retain) NSDate * date;
@property (nonatomic, retain) Student *student;

@end
