//
//  Student.m
//  StudentAttandanceLog
//
//  Created by Dave,Nakshatra on 4/24/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

#import "Student.h"
#import "Attendance.h"


@implementation Student

@dynamic classID;
@dynamic location;
@dynamic name;
@dynamic studentImage;
@dynamic absenceLog;

@end
