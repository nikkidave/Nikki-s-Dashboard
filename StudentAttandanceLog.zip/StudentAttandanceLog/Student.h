//
//  Student.h
//  StudentAttandanceLog
//
//  Created by Dave,Nakshatra on 4/24/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Attendance;

@interface Student : NSManagedObject

@property (nonatomic, retain) NSString * classID;
@property (nonatomic, retain) NSString * location;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) id studentImage;
@property (nonatomic, retain) NSSet *absenceLog;
@end

@interface Student (CoreDataGeneratedAccessors)

- (void)addAbsenceLogObject:(Attendance *)value;
- (void)removeAbsenceLogObject:(Attendance *)value;
- (void)addAbsenceLog:(NSSet *)values;
- (void)removeAbsenceLog:(NSSet *)values;

@end
